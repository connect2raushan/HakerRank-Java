/*
Welcome to the world of Java! Just print "Hello World." and "Hello Java." in two separate lines to complete this challenge.

The code stub in the editor already creates the main function and solution class. All you have to do is copy and paste the following lines inside the main function.

System.out.println("Hello World.");
System.out.println("Hello Java.");
Sample Output

Hello World.
Hello Java.
*/

public class WelcomeToJava {
   
   public static void main(String []argv)
   {
      System.out.println("Hello World.");
      System.out.println("Hello Java.");
   }

}
